import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
export async function middleware(request: NextRequest) {
  const url=process.env.NEXT_PUBLIC_SUPABASE_URL; const key=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if(!url||!key) return NextResponse.next();
  let response=NextResponse.next({request});
  const supabase=createServerClient(url,key,{cookies:{getAll:()=>request.cookies.getAll(),setAll(cookies){cookies.forEach(({name,value})=>request.cookies.set(name,value));response=NextResponse.next({request});cookies.forEach(({name,value,options})=>response.cookies.set(name,value,options));}}});
  const {data:{user}}=await supabase.auth.getUser();
  const publicPath=request.nextUrl.pathname==="/login"||request.nextUrl.pathname==="/register";
  if(!user&&!publicPath){const target=request.nextUrl.clone();target.pathname="/login";return NextResponse.redirect(target);}
  if(user&&publicPath){const target=request.nextUrl.clone();target.pathname="/dashboard";return NextResponse.redirect(target);}
  return response;
}
export const config={matcher:["/((?!_next/static|_next/image|favicon.ico|assets).*)"]};
